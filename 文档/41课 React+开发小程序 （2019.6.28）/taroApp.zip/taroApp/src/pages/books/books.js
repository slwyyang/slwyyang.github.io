import Taro, { Component } from '@tarojs/taro'
import { View, Button, Text ,Input} from '@tarojs/components'
import { AtButton,AtCard, AtList,AtListItem } from 'taro-ui'
import {observer, inject} from '@tarojs/mobx'
// function pay(){
//   if (process.env.TARO_ENV === 'weapp') {
//     require('微信支付接口')
//   } else if (process.env.TARO_ENV === 'alipay') {
//     // 编译的时候 只编译这个里面的代码
//     require('支付宝支付')
//   }
// }


// 注入我们需要的store

@inject('booksStore')
@observer
export default class Books extends Component{

  config={
    navigationBarTitleText:'图书馆'
  }
  constructor(props){
    super(props)
    this.state = {
      val:"",
      type:process.env.TARO_ENV
    }
  }
  handleInput = (e)=>{
    this.setState({
      val:e.target.value
    })
  }
  handleCilck = ()=>{
    // this.state.todos.push
    const {booksStore} = this.props
    booksStore.addTodo(this.state.val)
    this.setState({
      val:''
    })
  }
  handleChange = i=>{
    const {booksStore} = this.props
    booksStore.removeTodo(i)

  }
  render(){
    const {booksStore} = this.props
    return <View>
      <Text>开课吧taro demo -- {this.state.type}</Text>
      <Input value={this.state.val} onChange={this.handleInput}></Input>
      <AtButton type='primary' loading onClick={this.handleCilck}>添加</AtButton>
      <AtList>

      {
        booksStore.todos.map((item,i)=>{
          return <AtListItem 
            title={i+":"+item}
            isSwitch
            onSwitchChange={()=>this.handleChange(i)}
          >
           
          </AtListItem>
        })
      }
      </AtList>
      
      {/* {
        booksStore.todos.map((item,i)=>{
          return <View>
            <Text>{i+1} : {item}</Text>
          </View>
        })
      } */}
{/* <AtCard
  note='小Tips'
  extra='额外信息'
  title='这是个标题'
  thumb='http://www.logoquan.com/upload/list/20180421/logoquan15259400209.PNG'
>
  这也是内容区 可以随意定义功能
</AtCard> */}

    </View>
  }
}