<template>
    
    <div>
        <h1>hi {{name}}</h1>
    </div>
</template>

<script>
export default {
    data(){
        return {
            name:'首页'
        }
    }
}
</script>
