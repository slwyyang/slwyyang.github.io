<template>
    <div>
        <h1>用户相关的布局页</h1>
        <nuxt></nuxt>
    </div>
</template>
